package com.dataflix;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ActivityFeedRepository extends JpaRepository<ActivityFeed, Integer> {
    List<ActivityFeed> findAllByUserIdOrderByActivityDateDesc(Long userId);
}
