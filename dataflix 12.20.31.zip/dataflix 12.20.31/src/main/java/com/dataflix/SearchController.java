package com.dataflix;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.util.Date;
import java.util.List;

@Controller
public class SearchController {

    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private SeriesRepository seriesRepository;

    @Autowired
    private SearchHistoryRepository searchHistoryRepository;

    @GetMapping("/search")
    public String search(@RequestParam("q") String query, Principal principal, Model model) {
        List<Movie> movieResults = movieRepository.findByMovieNameContainingIgnoreCase(query);
        List<Series> seriesResults = seriesRepository.findBySeriesNameContainingIgnoreCase(query);

        // Arama geçmişine kaydet
        if (principal != null) {
            SearchHistory history = new SearchHistory();
            history.setUserId(1L); // sonra principal'dan alınacak
            history.setSearchText(query);
            history.setSearchDate(new Date());
            searchHistoryRepository.save(history);
        }

        model.addAttribute("query", query);
        model.addAttribute("movieResults", movieResults);
        model.addAttribute("seriesResults", seriesResults);

        if (movieResults.isEmpty()) {
            List<Movie> movieSuggestions = movieRepository.findSuggestions(query);
            model.addAttribute("movieSuggestions", movieSuggestions);
        }

        if (seriesResults.isEmpty()) {
            List<Series> seriesSuggestions = seriesRepository.findSuggestions(query);
            model.addAttribute("seriesSuggestions", seriesSuggestions);
        }

        return "search";
    }
}
