package com.dataflix;

import com.dataflix.MovieRating;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MovieRatingRepository extends JpaRepository<MovieRating, Integer> {
    List<MovieRating> findAllByMovie_MovieId(int movieId);
}
