package com.dataflix;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SeriesSoundtrackRepository extends JpaRepository<SeriesSoundtrack, Integer> {
    List<SeriesSoundtrack> findAllBySeries_SeriesId(int seriesId);
}
