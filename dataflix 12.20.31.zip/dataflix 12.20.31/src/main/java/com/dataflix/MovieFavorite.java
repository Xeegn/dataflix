package com.dataflix;

import jakarta.persistence.*;

@Entity
@Table(name = "movie_favorites")
public class MovieFavorite {

    @EmbeddedId
    private MovieFavoriteId id;

    @ManyToOne
    @MapsId("userId")
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @MapsId("movieId")
    @JoinColumn(name = "movie_id")
    private Movie movie;

    @Column(name = "added_date")
    private String addedDate;

    // getter-setter'lar...
}
