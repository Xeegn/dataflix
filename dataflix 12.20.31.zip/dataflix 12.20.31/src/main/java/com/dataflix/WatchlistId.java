package com.dataflix;

import java.io.Serializable;
import java.util.Objects;

public class WatchlistId implements Serializable {

    private Long userId;
    private int contentId;
    private ContentType contentType;

    public WatchlistId() {}

    public WatchlistId(Long userId, int contentId, ContentType contentType) {
        this.userId = userId;
        this.contentId = contentId;
        this.contentType = contentType;
    }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public int getContentId() { return contentId; }
    public void setContentId(int contentId) { this.contentId = contentId; }

    public ContentType getContentType() { return contentType; }
    public void setContentType(ContentType contentType) { this.contentType = contentType; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof WatchlistId)) return false;
        WatchlistId that = (WatchlistId) o;
        return contentId == that.contentId &&
                Objects.equals(userId, that.userId) &&
                contentType == that.contentType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, contentId, contentType);
    }
}
