package com.dataflix;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "search_history")
public class SearchHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "search_text")
    private String searchText;

    @Column(name = "search_date")
    private Date searchDate;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getSearchText() { return searchText; }
    public void setSearchText(String searchText) { this.searchText = searchText; }

    public Date getSearchDate() { return searchDate; }
    public void setSearchDate(Date searchDate) { this.searchDate = searchDate; }
}
