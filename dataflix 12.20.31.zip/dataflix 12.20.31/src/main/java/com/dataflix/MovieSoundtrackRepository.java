package com.dataflix;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MovieSoundtrackRepository extends JpaRepository<MovieSoundtrack, Integer> {
    List<MovieSoundtrack> findAllByMovie_MovieId(int movieId);
}
