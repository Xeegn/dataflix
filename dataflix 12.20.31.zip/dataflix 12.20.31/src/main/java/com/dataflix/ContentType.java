package com.dataflix;

public enum ContentType {
    movie,
    series
}
