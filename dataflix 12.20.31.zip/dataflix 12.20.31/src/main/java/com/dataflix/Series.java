package com.dataflix;

import jakarta.persistence.*;

@Entity
@Table(name = "series")
public class Series {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int seriesId;

    private String seriesName;
    private int seasonCount;
    private int episodeCount;
    private boolean ongoing;
    private String type;
    private double imdb;
    private int ageRequirement;

    public int getSeriesId() { return seriesId; }
    public void setSeriesId(int seriesId) { this.seriesId = seriesId; }

    public String getSeriesName() { return seriesName; }
    public void setSeriesName(String seriesName) { this.seriesName = seriesName; }

    public int getSeasonCount() { return seasonCount; }
    public void setSeasonCount(int seasonCount) { this.seasonCount = seasonCount; }

    public int getEpisodeCount() { return episodeCount; }
    public void setEpisodeCount(int episodeCount) { this.episodeCount = episodeCount; }

    public boolean isOngoing() { return ongoing; }
    public void setOngoing(boolean ongoing) { this.ongoing = ongoing; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public double getImdb() { return imdb; }
    public void setImdb(double imdb) { this.imdb = imdb; }

    public int getAgeRequirement() { return ageRequirement; }
    public void setAgeRequirement(int ageRequirement) { this.ageRequirement = ageRequirement; }
}
