package com.dataflix;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MovieCommentRepository extends JpaRepository<MovieComment, Integer> {
    List<MovieComment> findAllByMovie_MovieId(int movieId);
}
