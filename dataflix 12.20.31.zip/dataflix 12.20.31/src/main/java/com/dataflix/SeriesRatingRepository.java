package com.dataflix;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SeriesRatingRepository extends JpaRepository<SeriesRating, Integer> {
    List<SeriesRating> findAllBySeries_SeriesId(int seriesId);
}
