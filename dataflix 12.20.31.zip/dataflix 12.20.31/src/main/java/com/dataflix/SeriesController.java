package com.dataflix;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class SeriesController {

    @Autowired
    private SeriesRepository seriesRepository;

    @Autowired
    private SeriesCommentRepository seriesCommentRepository;

    @Autowired
    private SeriesRatingRepository seriesRatingRepository;

    @Autowired
    private SeriesSoundtrackRepository seriesSoundtrackRepository;

    @Autowired
    private SharedLinkRepository sharedLinkRepository;

    @GetMapping("/series/{id}")
    public String getSeriesDetail(@PathVariable int id, Model model) {
        Series series = seriesRepository.findById(id).orElse(null);
        if (series == null) return "redirect:/dashboard";

        List<SeriesComment> comments = seriesCommentRepository.findAllBySeries_SeriesId(id);
        List<SeriesRating> ratings = seriesRatingRepository.findAllBySeries_SeriesId(id);
        List<SeriesSoundtrack> soundtracks = seriesSoundtrackRepository.findAllBySeries_SeriesId(id);
        List<SharedLink> sharedLinks = sharedLinkRepository.findAllByContentIdAndContentType(id, ContentType.series);

        model.addAttribute("series", series);
        model.addAttribute("comments", comments);
        model.addAttribute("ratings", ratings);
        model.addAttribute("soundtracks", soundtracks);
        model.addAttribute("sharedLinks", sharedLinks);

        return "series_detail";
    }
}
