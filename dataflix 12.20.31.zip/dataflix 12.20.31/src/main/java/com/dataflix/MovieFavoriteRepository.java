package com.dataflix;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MovieFavoriteRepository extends JpaRepository<MovieFavorite, MovieFavoriteId> {
    List<MovieFavorite> findAllByUser(User user);
    List<MovieFavorite> findAllByUser_UserId(Long userId);
}
