package com.dataflix;

import jakarta.persistence.*;

@Entity
@Table(name = "series_ratings")
public class SeriesRating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int ratingId;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "series_id")
    private Series series;

    private int rating;

    public int getRatingId() { return ratingId; }
    public void setRatingId(int ratingId) { this.ratingId = ratingId; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Series getSeries() { return series; }
    public void setSeries(Series series) { this.series = series; }

    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }
}
