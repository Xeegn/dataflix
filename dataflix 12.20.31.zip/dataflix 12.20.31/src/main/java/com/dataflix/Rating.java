package com.dataflix;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "ratings")
@IdClass(RatingId.class)
public class Rating implements Serializable {

    @Id
    @Column(name = "user_id")
    private Long userId;

    @Id
    @Column(name = "content_id")
    private int contentId;

    @Id
    @Column(name = "content_type")
    @Enumerated(EnumType.STRING)
    private ContentType contentType;

    private Double rating;

    @Column(name = "rated_at")
    private Date ratedAt;

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public int getContentId() { return contentId; }
    public void setContentId(int contentId) { this.contentId = contentId; }

    public ContentType getContentType() { return contentType; }
    public void setContentType(ContentType contentType) { this.contentType = contentType; }

    public Double getRating() { return rating; }
    public void setRating(Double rating) { this.rating = rating; }

    public Date getRatedAt() { return ratedAt; }
    public void setRatedAt(Date ratedAt) { this.ratedAt = ratedAt; }
}
