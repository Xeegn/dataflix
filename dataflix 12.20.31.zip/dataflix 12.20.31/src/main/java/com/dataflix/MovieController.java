package com.dataflix;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class MovieController {

    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private MovieCommentRepository movieCommentRepository;

    @Autowired
    private MovieRatingRepository movieRatingRepository;

    @Autowired
    private MovieSoundtrackRepository movieSoundtrackRepository;

    @Autowired
    private SharedLinkRepository sharedLinkRepository;

    @GetMapping("/movie/{id}")
    public String getMovieDetail(@PathVariable int id, Model model) {
        Movie movie = movieRepository.findById(id).orElse(null);
        if (movie == null) return "redirect:/";

        List<MovieComment> comments = movieCommentRepository.findAllByMovie_MovieId(id);
        List<MovieRating> ratings = movieRatingRepository.findAllByMovie_MovieId(id);
        List<MovieSoundtrack> soundtracks = movieSoundtrackRepository.findAllByMovie_MovieId(id);
        List<SharedLink> sharedLinks = sharedLinkRepository.findAllByContentIdAndContentType(id, ContentType.movie);

        model.addAttribute("movie", movie);
        model.addAttribute("comments", comments);
        model.addAttribute("ratings", ratings);
        model.addAttribute("soundtracks", soundtracks);
        model.addAttribute("sharedLinks", sharedLinks);

        return "movie_detail";
    }
}
