package com.dataflix;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "series_comments")
public class SeriesComment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int commentId;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "series_id")
    private Series series;

    @Column(columnDefinition = "TEXT")
    private String commentText;

    private Date commentDate;

    public int getCommentId() { return commentId; }
    public void setCommentId(int commentId) { this.commentId = commentId; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Series getSeries() { return series; }
    public void setSeries(Series series) { this.series = series; }

    public String getCommentText() { return commentText; }
    public void setCommentText(String commentText) { this.commentText = commentText; }

    public Date getCommentDate() { return commentDate; }
    public void setCommentDate(Date commentDate) { this.commentDate = commentDate; }
}
