package com.dataflix;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "activity_feed")
public class ActivityFeed {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "user_id")
    private Long userId;

    private String activity; // örn: "added to favorites", "commented", "shared" vs.

    @Column(name = "content_type")
    @Enumerated(EnumType.STRING)
    private ContentType contentType;

    @Column(name = "content_id")
    private int contentId;

    @Column(name = "activity_date")
    private Date activityDate;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getActivity() { return activity; }
    public void setActivity(String activity) { this.activity = activity; }

    public ContentType getContentType() { return contentType; }
    public void setContentType(ContentType contentType) { this.contentType = contentType; }

    public int getContentId() { return contentId; }
    public void setContentId(int contentId) { this.contentId = contentId; }

    public Date getActivityDate() { return activityDate; }
    public void setActivityDate(Date activityDate) { this.activityDate = activityDate; }
}
