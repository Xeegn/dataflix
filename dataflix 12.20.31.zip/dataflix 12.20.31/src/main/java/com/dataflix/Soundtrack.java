package com.dataflix;

import jakarta.persistence.*;

@Entity
@Table(name = "soundtracks")
public class Soundtrack {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int soundtrackId;

    private String title;
    private String artist;
    private String duration;

    public int getSoundtrackId() { return soundtrackId; }
    public void setSoundtrackId(int soundtrackId) { this.soundtrackId = soundtrackId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getArtist() { return artist; }
    public void setArtist(String artist) { this.artist = artist; }

    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }
}
