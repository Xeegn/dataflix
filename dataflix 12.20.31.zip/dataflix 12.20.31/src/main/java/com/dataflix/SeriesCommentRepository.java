package com.dataflix;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SeriesCommentRepository extends JpaRepository<SeriesComment, Integer> {
    List<SeriesComment> findAllBySeries_SeriesId(int seriesId);
}
