package com.dataflix;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface SeriesRepository extends JpaRepository<Series, Integer> {

    @Query("SELECT s FROM Series s WHERE LOWER(s.seriesName) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Series> findSuggestions(@Param("keyword") String keyword);

    List<Series> findBySeriesNameContainingIgnoreCase(String name);
}
