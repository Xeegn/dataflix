package com.dataflix;

import jakarta.persistence.*;

@Entity
@Table(name = "movies")
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int movieId;

    private String movieName;
    private double imdb;
    private int duration;
    private String type;
    private int ageRequirement;

    public int getMovieId() { return movieId; }
    public void setMovieId(int movieId) { this.movieId = movieId; }

    public String getMovieName() { return movieName; }
    public void setMovieName(String movieName) { this.movieName = movieName; }

    public double getImdb() { return imdb; }
    public void setImdb(double imdb) { this.imdb = imdb; }

    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public int getAgeRequirement() { return ageRequirement; }
    public void setAgeRequirement(int ageRequirement) { this.ageRequirement = ageRequirement; }
}
