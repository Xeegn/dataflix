package com.dataflix;

import jakarta.persistence.*;

@Entity
@Table(name = "series_soundtracks")
public class SeriesSoundtrack {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "series_id")
    private Series series;

    @ManyToOne
    @JoinColumn(name = "soundtrack_id")
    private Soundtrack soundtrack;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Series getSeries() { return series; }
    public void setSeries(Series series) { this.series = series; }

    public Soundtrack getSoundtrack() { return soundtrack; }
    public void setSoundtrack(Soundtrack soundtrack) { this.soundtrack = soundtrack; }
}
