package com.dataflix;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface WatchedRepository extends JpaRepository<Watched, WatchedId> {
    List<Watched> findAllByUserId(Long userId);
}
