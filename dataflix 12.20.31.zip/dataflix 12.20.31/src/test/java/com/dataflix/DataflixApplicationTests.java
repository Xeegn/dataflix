package com.dataflix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataflixApplicationTests {

	@Test
	void contextLoads() {
	}

}
